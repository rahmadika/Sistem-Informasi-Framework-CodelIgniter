<?php
/*
| ---------------------------------------------------------------------------
| Nama Program	      : V01_KopLem.php
| Lokasi Folders      : “/Views/V0001/” 
| Fungsi Program	  : Mengakses Kop Lembaga 
| Tanggal Programming : Bandung, 29 Desember 2021  
| Sistem Analist	  : Nana Karyana Kurdi, SE., M.Kom.
| Programmer		  :  nama mahasiswa
| ---------------------------------------------------------------------------
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <title>Kop Lembaga</title>
   <link rel="stylesheet" type="text/css" href="<?php echo base_url('css/background_01.css') ?>" />
</head>

<body>
   <Center>
       <div id="container">
	  <h1><div class="pics">
      </div></h1>
    <!-- </Center> -->
</body>
</html>
